import json
import os
import boto3
import urllib.request
import time
from jose import jwk, jwt
from jose.utils import base64url_decode

dynamodb = boto3.resource('dynamodb')

USER_TABLE = os.environ.get('USER_TABLE', 'UserProfiles_KY')
PROJECT_TABLE = os.environ.get('PROJECT_TABLE', 'ProjectRooms_KY')
REGION = os.environ.get('REGION', 'ap-northeast-2')
USER_POOL_ID = os.environ.get('USER_POOL_ID', 'your_userpool_id')
APP_CLIENT_ID = os.environ.get('APP_CLIENT_ID', 'your_appclient_id')

user_table = dynamodb.Table(USER_TABLE)
project_table = dynamodb.Table(PROJECT_TABLE)

# JWKS 가져오기 (캐싱 고려 가능)
keys_url = f"https://cognito-idp.{REGION}.amazonaws.com/{USER_POOL_ID}/.well-known/jwks.json"
with urllib.request.urlopen(keys_url) as f:
    jwks = json.loads(f.read())['keys']

def verify_token(token):
    headers = jwt.get_unverified_headers(token)
    kid = headers['kid']
    key = next((k for k in jwks if k['kid'] == kid), None)
    if not key:
        raise Exception("Public key not found in jwks.json")
    public_key = jwk.construct(key)
    message, encoded_signature = str(token).rsplit('.', 1)
    decoded_signature = base64url_decode(encoded_signature.encode('utf-8'))
    if not public_key.verify(message.encode('utf-8'), decoded_signature):
        raise Exception("Signature verification failed")

    claims = jwt.get_unverified_claims(token)
    if claims['iss'] != f"https://cognito-idp.{REGION}.amazonaws.com/{USER_POOL_ID}":
        raise Exception("Invalid issuer")
    if claims['aud'] != APP_CLIENT_ID:
        raise Exception("Invalid audience")
    if claims['exp'] < int(time.time()):
        raise Exception("Token is expired")
    return claims

def lambda_handler(event, context):
    # Authorization 헤더에서 토큰 추출
    auth_header = event.get('headers', {}).get('Authorization', '')
    if not auth_header.startswith('Bearer '):
        return {
            "statusCode": 401,
            "body": json.dumps({"error": "Unauthorized"})
        }
    token = auth_header.split(' ')[1]

    # 토큰 검증 및 userId(claims['sub']) 획득
    try:
        claims = verify_token(token)
    except Exception as e:
        return {
            "statusCode": 401,
            "body": json.dumps({"error": str(e)})
        }

    user_id = claims.get('sub')
    if not user_id:
        return {
            "statusCode": 401,
            "body": json.dumps({"error": "No sub in token"})
        }

    # user_id로 사용자 정보 가져오기
    user_resp = user_table.get_item(Key={"UserID": user_id})
    user_item = user_resp.get('Item', {})

    user_preferences_raw = user_item.get('user-project-preference', '')
    user_techstack_raw = user_item.get('user-techstack', '')

    # 문자열을 리스트로 변환 (필요 시)
    user_preferences = [pref.strip() for pref in user_preferences_raw.split(',')] if isinstance(user_preferences_raw, str) else user_preferences_raw
    user_techstack = [ts.strip() for ts in user_techstack_raw.split(',')] if isinstance(user_techstack_raw, str) else user_techstack_raw

    project_resp = project_table.scan()
    all_projects = project_resp.get('Items', [])

    filtered_projects = []
    for p in all_projects:
        p_type = p.get('projectType', '')
        p_techstack = p.get('techStack', [])
        if p_type in user_preferences and any(stack in p_techstack for stack in user_techstack):
            filtered_projects.append(p)

    return {
        "statusCode": 200,
        "body": json.dumps(filtered_projects, ensure_ascii=False)
    }
